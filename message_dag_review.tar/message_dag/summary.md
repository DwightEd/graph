# 消息 DAG：结构与正常／幻觉比较

选中 2/688 个已完成原生样本；已完成 8/8 个计划目标；所选样本共有 268 个普通目标。
图按来源单位传播，并从同一个目标反向计入全部后续路径。稀疏边仅用于显示。
这些是条件归因与探索性结构差异，不能直接命名为错误捷径或事实约束失败。

| cohort | N | H | unknown | matched | missing graphs |
|---|---:|---:|---:|---:|---:|
| train/QA | 8 | 0 | 0 | 0 | 0 |

cohorts/*.npz：来源等权的结构与逐 head N/H 均值、位置配对差异、区间及 BY 校正。
稀疏目标预算可能没有两侧正常对照；缺失显示为缺失，不解释为无差异。
summary.json 的 detection_diagnostics 保留材料支持不足这一固定对照及直接读出、logprob、位置的 AUROC/AP。
该分数不是完整图模型，也不是已发现机制；多跳路径贡献不能沿所有边相加当作一次输出。

## train 固定检测对照

| task | score | AUROC | AP |
|---|---|---:|---:|
| ALL | material_deficit | NA | NA |
| ALL | direct_deficit | NA | NA |
| ALL | negative_logprob | NA | NA |
| ALL | position | NA | NA |
| QA | material_deficit | NA | NA |
| QA | direct_deficit | NA | NA |
| QA | negative_logprob | NA | NA |
| QA | position | NA | NA |
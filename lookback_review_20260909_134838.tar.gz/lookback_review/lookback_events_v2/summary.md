# 内部回看事件审计

请求原生样本 2946；完成扫描 1；回看位置 46；完成传播 0；无事件样本 0。

所有可用事件均计划传播；缺失缓存及未完成事件见 summary.json。源可以是 prompt 或旧回答。
预测目标 t 使用 query t−1；回看载体 b 本身的标签不代替其后续目标标签。
offset=0 指 b 预测的第一个 token b+1。未来不足记为缺失，不填零。
后续统计使用每个实际可用的普通 query/target；17–64、65+ 区间按可用目标汇总，需同时看暴露数量。

## 结构复核

cohorts/*_heads.png 的每格是一个物理 layer/head 的 H−N 差，绝非一个幻觉 token。
三排分别是全部匹配 H、已知 N→H 起点、已知 H→H 延续；不将未知边界算成起点或延续。
time_tv 是同一 head 在相邻 query token 间的 attention 总变差，不是层间或头间变化。
同回答、同粗 token 类别、两侧32 token 内正常对照插值；先回答内，再 source 等权。
95%区间对 source 重抽样。它不是全 head 多重检验后的显著性声明；没有匹配支持则无图。

## 事件传播

cohorts/event_outcomes.csv 汇总事件之后的 N/H 响应，先回答内再 source 等权；重复事件不作为独立 source。
同一 source 的完整结果保存在每个 event_<绝对位置>.npz；所有实际后续 token 均参与传播。
observed_runner 的正负仅表示对当前 token 相对 runner 的支持，不能自动当成正确／错误证据。
explicit_candidates 单独汇总，不与 observed_runner 混合；单 token 候选也不等于完整事实判定。
cohorts/candidate_states.csv 保存当前候选差，以及 M<0 且完整消息响应 C>0 的 source 等权比例。
该比例描述名义正候选落后而消息增强有正向局部增益；只有候选真值独立确定，才可联系正确／错误证据。
0/1/2+ 跳相加还原总局部响应；full−fixed_qk 与 full−no_mlp_paths 两个路径差有重叠。
状态范数、MLP方向抵消不直接等于信息量或语义丢失。teacher forcing 不证明自由生成闭环。

## 有符号传播图与固定检测候选

`edges_<b>.npz`保存全部物理层/头、中继、目标的V/K边，未用top-k截断。
每条路径按最后跨位置边计入一次；`cut_closure_error`核对直接/多跳之和与原响应一致。
这分解的是候选差的局部导数，不是候选差本身，也不是已经解耦的正确事实流量。
`transport_detection.json/png`报告固定 opposition 分数及直接路径、V-only、置信度、位置对照。
比较使用相同有效token并按source配对重抽样；具体条件覆盖与缺失原因必须同时查看。
没有此前事件、零作用、未完成传播或明确真值候选的位置不填零，不算入无监督检测。
该分数尚需真实8B数据检验，不将正负路径作用直接命名为幻觉机制。
